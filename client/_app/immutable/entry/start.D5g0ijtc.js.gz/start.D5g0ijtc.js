import{l as o,d as r}from"../chunks/BlOL-Os8.js";export{o as load_css,r as start};
