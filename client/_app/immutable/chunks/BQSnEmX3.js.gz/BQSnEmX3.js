import{e}from"./CP5tR_5M.js";e();
